// swift-tools-version:5.5
import PackageDescription

let package = Package(
    name: "UnifiedVideoPlayer",
    platforms: [
        .iOS(.v13),
        .tvOS(.v13),
        .macCatalyst(.v13)
    ],
    products: [
        .library(
            name: "UnifiedVideoPlayer",
            type: .dynamic,
            targets: ["UnifiedVideoPlayer"]
        )
    ],
    dependencies: [],
    targets: [
        .target(
            name: "UnifiedVideoPlayer",
            dependencies: [],
            path: "Sources/UnifiedVideoPlayer",
            swiftSettings: [
                .unsafeFlags(["-enable-library-evolution"])
            ]
        ),
        .testTarget(
            name: "UnifiedVideoPlayerTests",
            dependencies: ["UnifiedVideoPlayer"],
            path: "Tests/UnifiedVideoPlayerTests"
        )
    ],
    swiftLanguageVersions: [.v5]
)
