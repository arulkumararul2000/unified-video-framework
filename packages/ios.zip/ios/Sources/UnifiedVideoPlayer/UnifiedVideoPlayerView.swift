//
//  UnifiedVideoPlayerView.swift
//  UnifiedVideoPlayer
//
//  SwiftUI implementation of the Unified Video Framework
//

import SwiftUI
import AVKit
import AVFoundation
import Combine

// MARK: - SwiftUI Video Player View
@available(iOS 14.0, *)
public struct UnifiedVideoPlayerView: UIViewControllerRepresentable {
    @Binding var player: UnifiedVideoPlayerModel
    var showsControls: Bool = true
    
    public init(player: Binding<UnifiedVideoPlayerModel>, showsControls: Bool = true) {
        self._player = player
        self.showsControls = showsControls
    }
    
    public func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player.avPlayer
        controller.showsPlaybackControls = showsControls
        return controller
    }
    
    public func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        uiViewController.player = player.avPlayer
        uiViewController.showsPlaybackControls = showsControls
    }
}

// MARK: - Custom SwiftUI Video Player with Controls
@available(iOS 14.0, *)
public struct CustomUnifiedVideoPlayer: View {
    @StateObject private var playerModel: UnifiedVideoPlayerModel
    @State private var showControls: Bool = true
    @State private var hideControlsTimer: Timer?
    
    // Configuration
    private let configuration: PlayerConfiguration
    
    public init(url: String, configuration: PlayerConfiguration = PlayerConfiguration()) {
        self.configuration = configuration
        self._playerModel = StateObject(wrappedValue: UnifiedVideoPlayerModel(url: url, configuration: configuration))
    }
    
    public init(source: MediaSource, configuration: PlayerConfiguration = PlayerConfiguration()) {
        self.configuration = configuration
        self._playerModel = StateObject(wrappedValue: UnifiedVideoPlayerModel(source: source, configuration: configuration))
    }
    
    public var body: some View {
        ZStack {
            // Video Player Layer
            VideoPlayerLayer(player: playerModel.avPlayer)
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        showControls.toggle()
                        resetHideControlsTimer()
                    }
                }
            
            // Custom Controls Overlay
            if showControls && configuration.controls {
                VideoControlsOverlay(playerModel: playerModel)
                    .transition(.opacity)
            }
            
            // Loading Indicator
            if playerModel.isBuffering {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    .scaleEffect(1.5)
            }
            
            // Error Message
            if let error = playerModel.error {
                VStack {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    Text(error.localizedDescription)
                        .foregroundColor(.white)
                        .padding()
                }
                .background(Color.black.opacity(0.7))
                .cornerRadius(10)
            }
        }
        .background(Color.black)
        .onAppear {
            playerModel.initialize()
            resetHideControlsTimer()
        }
        .onDisappear {
            playerModel.cleanup()
        }
    }
    
    private func resetHideControlsTimer() {
        hideControlsTimer?.invalidate()
        hideControlsTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { _ in
            withAnimation {
                showControls = false
            }
        }
    }
}

// MARK: - Video Player Layer
@available(iOS 14.0, *)
struct VideoPlayerLayer: UIViewRepresentable {
    let player: AVPlayer?
    
    func makeUIView(context: Context) -> PlayerUIView {
        return PlayerUIView(player: player)
    }
    
    func updateUIView(_ uiView: PlayerUIView, context: Context) {
        uiView.updatePlayer(player)
    }
    
    class PlayerUIView: UIView {
        private var playerLayer: AVPlayerLayer?
        
        init(player: AVPlayer?) {
            super.init(frame: .zero)
            setupPlayerLayer(with: player)
        }
        
        required init?(coder: NSCoder) {
            super.init(coder: coder)
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            playerLayer?.frame = bounds
        }
        
        func setupPlayerLayer(with player: AVPlayer?) {
            playerLayer?.removeFromSuperlayer()
            
            guard let player = player else { return }
            
            let newPlayerLayer = AVPlayerLayer(player: player)
            newPlayerLayer.videoGravity = .resizeAspect
            newPlayerLayer.frame = bounds
            layer.addSublayer(newPlayerLayer)
            playerLayer = newPlayerLayer
        }
        
        func updatePlayer(_ player: AVPlayer?) {
            playerLayer?.player = player
        }
    }
}

// MARK: - Video Controls Overlay
@available(iOS 14.0, *)
struct VideoControlsOverlay: View {
    @ObservedObject var playerModel: UnifiedVideoPlayerModel
    @State private var isDraggingSlider: Bool = false
    
    var body: some View {
        VStack {
            // Top Bar
            HStack {
                if let title = playerModel.title {
                    Text(title)
                        .font(.headline)
                        .foregroundColor(.white)
                }
                Spacer()
                
                // Settings Menu
                Menu {
                    // Quality Selection
                    Menu("Quality") {
                        ForEach(["Auto", "1080p", "720p", "480p", "360p"], id: \.self) { quality in
                            Button(quality) {
                                playerModel.setVideoQuality(quality)
                            }
                        }
                    }
                    
                    // Playback Speed
                    Menu("Speed") {
                        ForEach([0.5, 0.75, 1.0, 1.25, 1.5, 2.0], id: \.self) { speed in
                            Button("\(speed)x") {
                                playerModel.setPlaybackRate(Float(speed))
                            }
                        }
                    }
                    
                    // Subtitles
                    if !playerModel.availableSubtitles.isEmpty {
                        Menu("Subtitles") {
                            Button("Off") {
                                playerModel.selectSubtitle(nil)
                            }
                            ForEach(playerModel.availableSubtitles, id: \.language) { subtitle in
                                Button(subtitle.label) {
                                    playerModel.selectSubtitle(subtitle)
                                }
                            }
                        }
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .foregroundColor(.white)
                        .font(.title2)
                }
            }
            .padding()
            .background(LinearGradient(
                gradient: Gradient(colors: [Color.black.opacity(0.7), Color.clear]),
                startPoint: .top,
                endPoint: .bottom
            ))
            
            Spacer()
            
            // Center Play/Pause Button
            if !playerModel.isPlaying {
                Button(action: {
                    playerModel.play()
                }) {
                    Image(systemName: "play.circle.fill")
                        .font(.system(size: 70))
                        .foregroundColor(.white.opacity(0.9))
                }
            }
            
            Spacer()
            
            // Bottom Controls
            VStack(spacing: 10) {
                // Progress Bar
                HStack {
                    Text(formatTime(playerModel.currentTime))
                        .font(.caption)
                        .foregroundColor(.white)
                    
                    Slider(
                        value: Binding(
                            get: { isDraggingSlider ? playerModel.seekTime : playerModel.currentTime },
                            set: { playerModel.seekTime = $0 }
                        ),
                        in: 0...max(playerModel.duration, 1),
                        onEditingChanged: { editing in
                            isDraggingSlider = editing
                            if !editing {
                                playerModel.seek(to: playerModel.seekTime)
                            }
                        }
                    )
                    .accentColor(.white)
                    
                    Text(formatTime(playerModel.duration))
                        .font(.caption)
                        .foregroundColor(.white)
                }
                .padding(.horizontal)
                
                // Control Buttons
                HStack(spacing: 30) {
                    // Play/Pause
                    Button(action: {
                        playerModel.togglePlayPause()
                    }) {
                        Image(systemName: playerModel.isPlaying ? "pause.fill" : "play.fill")
                            .font(.title)
                            .foregroundColor(.white)
                    }
                    
                    // Skip Backward
                    Button(action: {
                        playerModel.seekBackward()
                    }) {
                        Image(systemName: "gobackward.10")
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                    
                    // Skip Forward
                    Button(action: {
                        playerModel.seekForward()
                    }) {
                        Image(systemName: "goforward.10")
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
                    
                    // Volume
                    HStack {
                        Image(systemName: playerModel.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                            .foregroundColor(.white)
                            .onTapGesture {
                                playerModel.toggleMute()
                            }
                        
                        Slider(value: $playerModel.volume, in: 0...1)
                            .frame(width: 80)
                            .accentColor(.white)
                    }
                    
                    // Fullscreen
                    Button(action: {
                        playerModel.toggleFullscreen()
                    }) {
                        Image(systemName: playerModel.isFullscreen ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
            .background(LinearGradient(
                gradient: Gradient(colors: [Color.clear, Color.black.opacity(0.7)]),
                startPoint: .top,
                endPoint: .bottom
            ))
        }
    }
    
    private func formatTime(_ time: Double) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

// MARK: - Player Model (ObservableObject)
@available(iOS 14.0, *)
public class UnifiedVideoPlayerModel: ObservableObject {
    // Published Properties
    @Published public var isPlaying: Bool = false
    @Published public var isBuffering: Bool = false
    @Published public var currentTime: Double = 0
    @Published public var duration: Double = 0
    @Published public var seekTime: Double = 0
    @Published public var volume: Float = 1.0 {
        didSet { avPlayer?.volume = volume }
    }
    @Published public var isMuted: Bool = false {
        didSet { avPlayer?.isMuted = isMuted }
    }
    @Published public var error: Error?
    @Published public var isFullscreen: Bool = false
    @Published public var title: String?
    @Published public var availableSubtitles: [SubtitleTrack] = []
    @Published public var currentVideoQuality: String = "Auto"
    
    // Player properties
    public private(set) var avPlayer: AVPlayer?
    private var playerObserver: Any?
    private var timeObserver: Any?
    private var cancellables = Set<AnyCancellable>()
    private let configuration: PlayerConfiguration
    private var mediaSource: MediaSource?
    
    // Events
    public var onReady: (() -> Void)?
    public var onEnded: (() -> Void)?
    public var onError: ((Error) -> Void)?
    
    // MARK: - Initialization
    
    public init(url: String, configuration: PlayerConfiguration = PlayerConfiguration()) {
        self.configuration = configuration
        self.mediaSource = MediaSource(url: url)
        setupPlayer()
    }
    
    public init(source: MediaSource, configuration: PlayerConfiguration = PlayerConfiguration()) {
        self.configuration = configuration
        self.mediaSource = source
        setupPlayer()
    }
    
    // MARK: - Player Setup
    
    private func setupPlayer() {
        guard let source = mediaSource,
              let url = URL(string: source.url) else { return }
        
        let playerItem = AVPlayerItem(url: url)
        avPlayer = AVPlayer(playerItem: playerItem)
        
        // Apply configuration
        avPlayer?.volume = configuration.volume
        avPlayer?.isMuted = configuration.muted
        
        // Setup observers
        setupObservers()
        
        // Load metadata
        if let metadata = source.metadata {
            title = metadata["title"] as? String
        }
        
        // Load subtitles if available
        if let subtitles = source.subtitles {
            availableSubtitles = subtitles
        }
    }
    
    public func initialize() {
        if configuration.autoPlay {
            play()
        }
    }
    
    // MARK: - Playback Control
    
    public func play() {
        avPlayer?.play()
        isPlaying = true
    }
    
    public func pause() {
        avPlayer?.pause()
        isPlaying = false
    }
    
    public func togglePlayPause() {
        if isPlaying {
            pause()
        } else {
            play()
        }
    }
    
    public func stop() {
        avPlayer?.pause()
        avPlayer?.seek(to: .zero)
        isPlaying = false
        currentTime = 0
    }
    
    public func seek(to time: Double) {
        let cmTime = CMTime(seconds: time, preferredTimescale: 1000)
        avPlayer?.seek(to: cmTime)
    }
    
    public func seekForward(seconds: Double = 10) {
        let newTime = currentTime + seconds
        seek(to: min(newTime, duration))
    }
    
    public func seekBackward(seconds: Double = 10) {
        let newTime = currentTime - seconds
        seek(to: max(newTime, 0))
    }
    
    // MARK: - Configuration
    
    public func setPlaybackRate(_ rate: Float) {
        avPlayer?.rate = rate
    }
    
    public func setVideoQuality(_ quality: String) {
        currentVideoQuality = quality
        // Implementation would handle quality switching
    }
    
    public func selectSubtitle(_ subtitle: SubtitleTrack?) {
        // Implementation would handle subtitle selection
    }
    
    public func toggleMute() {
        isMuted.toggle()
    }
    
    public func toggleFullscreen() {
        isFullscreen.toggle()
    }
    
    // MARK: - Observers
    
    private func setupObservers() {
        // Time observer
        let interval = CMTime(seconds: 0.1, preferredTimescale: 1000)
        timeObserver = avPlayer?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            self?.currentTime = time.seconds
        }
        
        // Status observer
        avPlayer?.publisher(for: \.status)
            .sink { [weak self] status in
                if status == .readyToPlay {
                    self?.updateDuration()
                    self?.onReady?()
                }
            }
            .store(in: &cancellables)
        
        // Rate observer
        avPlayer?.publisher(for: \.rate)
            .sink { [weak self] rate in
                self?.isPlaying = rate > 0
            }
            .store(in: &cancellables)
        
        // Buffering observer
        avPlayer?.currentItem?.publisher(for: \.isPlaybackBufferEmpty)
            .sink { [weak self] isEmpty in
                self?.isBuffering = isEmpty
            }
            .store(in: &cancellables)
        
        // End observer
        NotificationCenter.default.publisher(for: .AVPlayerItemDidPlayToEndTime)
            .sink { [weak self] _ in
                self?.handlePlaybackEnded()
            }
            .store(in: &cancellables)
        
        // Error observer
        avPlayer?.currentItem?.publisher(for: \.error)
            .compactMap { $0 }
            .sink { [weak self] error in
                self?.error = error
                self?.onError?(error)
            }
            .store(in: &cancellables)
    }
    
    private func updateDuration() {
        if let duration = avPlayer?.currentItem?.duration {
            self.duration = duration.seconds
        }
    }
    
    private func handlePlaybackEnded() {
        if configuration.loop {
            seek(to: 0)
            play()
        } else {
            isPlaying = false
            onEnded?()
        }
    }
    
    // MARK: - Cleanup
    
    public func cleanup() {
        avPlayer?.pause()
        if let observer = timeObserver {
            avPlayer?.removeTimeObserver(observer)
        }
        cancellables.removeAll()
    }
    
    deinit {
        cleanup()
    }
}

// MARK: - SwiftUI Preview Provider
@available(iOS 14.0, *)
struct UnifiedVideoPlayerView_Previews: PreviewProvider {
    static var previews: some View {
        CustomUnifiedVideoPlayer(
            url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
        )
    }
}
