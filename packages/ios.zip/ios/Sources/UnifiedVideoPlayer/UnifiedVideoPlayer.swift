//
//  UnifiedVideoPlayer.swift
//  UnifiedVideoPlayer
//
//  Unified Video Framework - iOS Native SDK
//

import Foundation
import AVFoundation
import AVKit
import UIKit

// MARK: - Player Configuration
@objc public class PlayerConfiguration: NSObject {
    @objc public var autoPlay: Bool = false
    @objc public var controls: Bool = true
    @objc public var muted: Bool = false
    @objc public var loop: Bool = false
    @objc public var preload: String = "auto"
    @objc public var startTime: Double = 0
    @objc public var playbackRate: Float = 1.0
    @objc public var volume: Float = 1.0
    @objc public var debug: Bool = false
    
    @objc public override init() {
        super.init()
    }
    
    @objc public init(dictionary: [String: Any]) {
        super.init()
        autoPlay = dictionary["autoPlay"] as? Bool ?? false
        controls = dictionary["controls"] as? Bool ?? true
        muted = dictionary["muted"] as? Bool ?? false
        loop = dictionary["loop"] as? Bool ?? false
        preload = dictionary["preload"] as? String ?? "auto"
        startTime = dictionary["startTime"] as? Double ?? 0
        playbackRate = dictionary["playbackRate"] as? Float ?? 1.0
        volume = dictionary["volume"] as? Float ?? 1.0
        debug = dictionary["debug"] as? Bool ?? false
    }
}

// MARK: - Media Source
@objc public class MediaSource: NSObject {
    @objc public var url: String
    @objc public var type: String?
    @objc public var drm: DRMConfiguration?
    @objc public var metadata: [String: Any]?
    @objc public var subtitles: [SubtitleTrack]?
    
    @objc public init(url: String, type: String? = nil) {
        self.url = url
        self.type = type ?? MediaSource.detectType(from: url)
    }
    
    private static func detectType(from url: String) -> String {
        if url.contains(".m3u8") { return "hls" }
        if url.contains(".mpd") { return "dash" }
        if url.contains(".mp4") { return "mp4" }
        if url.contains(".webm") { return "webm" }
        return "mp4"
    }
}

// MARK: - DRM Configuration
@objc public class DRMConfiguration: NSObject {
    @objc public var type: String // fairplay, widevine
    @objc public var licenseUrl: String
    @objc public var certificateUrl: String?
    @objc public var headers: [String: String]?
    
    @objc public init(type: String, licenseUrl: String) {
        self.type = type
        self.licenseUrl = licenseUrl
    }
}

// MARK: - Subtitle Track
@objc public class SubtitleTrack: NSObject {
    @objc public var url: String
    @objc public var language: String
    @objc public var label: String
    @objc public var kind: String // subtitles, captions
    
    @objc public init(url: String, language: String, label: String, kind: String = "subtitles") {
        self.url = url
        self.language = language
        self.label = label
        self.kind = kind
    }
}

// MARK: - Player State
@objc public enum PlayerState: Int {
    case idle = 0
    case loading = 1
    case ready = 2
    case playing = 3
    case paused = 4
    case buffering = 5
    case seeking = 6
    case ended = 7
    case error = 8
}

// MARK: - Main Player Class
@objc public class UnifiedVideoPlayer: NSObject {
    
    // MARK: Properties
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var playerViewController: AVPlayerViewController?
    private var containerView: UIView?
    private var configuration: PlayerConfiguration?
    private var currentSource: MediaSource?
    
    private var timeObserver: Any?
    private var statusObserver: NSKeyValueObservation?
    private var rateObserver: NSKeyValueObservation?
    private var currentItemObserver: NSKeyValueObservation?
    
    @objc public private(set) var state: PlayerState = .idle
    @objc public private(set) var isPlaying: Bool = false
    @objc public private(set) var duration: Double = 0
    @objc public private(set) var currentTime: Double = 0
    @objc public private(set) var bufferedTime: Double = 0
    
    // MARK: - Event Callbacks
    @objc public var onReady: (() -> Void)?
    @objc public var onPlay: (() -> Void)?
    @objc public var onPause: (() -> Void)?
    @objc public var onTimeUpdate: ((Double) -> Void)?
    @objc public var onBuffering: ((Bool) -> Void)?
    @objc public var onSeek: ((Double) -> Void)?
    @objc public var onEnded: (() -> Void)?
    @objc public var onError: ((Error) -> Void)?
    @objc public var onLoadedMetadata: (([String: Any]) -> Void)?
    @objc public var onVolumeChange: ((Float) -> Void)?
    @objc public var onStateChange: ((PlayerState) -> Void)?
    @objc public var onProgress: ((Double) -> Void)?
    
    // MARK: - Initialization
    
    @objc public override init() {
        super.init()
    }
    
    @objc public func initialize(container: UIView, configuration: PlayerConfiguration? = nil) {
        self.containerView = container
        self.configuration = configuration ?? PlayerConfiguration()
        
        setupPlayer()
        applyConfiguration()
    }
    
    @objc public func initializeWithViewController(viewController: UIViewController, configuration: PlayerConfiguration? = nil) {
        self.configuration = configuration ?? PlayerConfiguration()
        
        playerViewController = AVPlayerViewController()
        setupPlayer()
        applyConfiguration()
        
        if let playerVC = playerViewController {
            playerVC.player = player
            viewController.present(playerVC, animated: true)
        }
    }
    
    private func setupPlayer() {
        player = AVPlayer()
        
        if let container = containerView {
            playerLayer = AVPlayerLayer(player: player)
            playerLayer?.frame = container.bounds
            playerLayer?.videoGravity = .resizeAspect
            
            if let layer = playerLayer {
                container.layer.addSublayer(layer)
            }
            
            // Add default controls if enabled
            if configuration?.controls == true && playerViewController == nil {
                addDefaultControls()
            }
        }
        
        setupObservers()
        updateState(.idle)
    }
    
    private func applyConfiguration() {
        guard let config = configuration else { return }
        
        player?.volume = config.volume
        player?.rate = config.playbackRate
        player?.isMuted = config.muted
        
        if config.debug {
            enableDebugLogging()
        }
    }
    
    // MARK: - Loading Content
    
    @objc public func load(source: MediaSource) {
        currentSource = source
        updateState(.loading)
        
        guard let url = URL(string: source.url) else {
            let error = NSError(domain: "UnifiedVideoPlayer", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])
            handleError(error)
            return
        }
        
        // Handle DRM if configured
        if let drm = source.drm, drm.type == "fairplay" {
            loadFairPlayContent(url: url, drm: drm)
        } else {
            loadStandardContent(url: url)
        }
        
        // Load subtitles if provided
        if let subtitles = source.subtitles {
            loadSubtitles(subtitles)
        }
    }
    
    @objc public func load(url: String) {
        let source = MediaSource(url: url)
        load(source: source)
    }
    
    private func loadStandardContent(url: URL) {
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        
        // Add observers for the player item
        observePlayerItem(playerItem)
        
        player?.replaceCurrentItem(with: playerItem)
        
        // Apply start time if configured
        if let startTime = configuration?.startTime, startTime > 0 {
            seek(to: startTime)
        }
        
        // Auto-play if configured
        if configuration?.autoPlay == true {
            play()
        }
    }
    
    private func loadFairPlayContent(url: URL, drm: DRMConfiguration) {
        // FairPlay implementation
        let asset = AVURLAsset(url: url)
        
        // Configure FairPlay
        asset.resourceLoader.setDelegate(self, queue: DispatchQueue.main)
        
        let playerItem = AVPlayerItem(asset: asset)
        observePlayerItem(playerItem)
        player?.replaceCurrentItem(with: playerItem)
        
        if configuration?.autoPlay == true {
            play()
        }
    }
    
    private func loadSubtitles(_ subtitles: [SubtitleTrack]) {
        guard let playerItem = player?.currentItem else { return }
        
        for subtitle in subtitles {
            guard let url = URL(string: subtitle.url) else { continue }
            
            let asset = AVAsset(url: url)
            let track = AVMutableMetadataItem()
            track.identifier = .commonIdentifierTitle
            track.value = subtitle.label as NSString
            track.extendedLanguageTag = subtitle.language
            
            // Note: Full subtitle implementation would require more complex AVAssetReader setup
        }
    }
    
    // MARK: - Playback Control
    
    @objc public func play() {
        player?.play()
        isPlaying = true
        updateState(.playing)
        onPlay?()
    }
    
    @objc public func pause() {
        player?.pause()
        isPlaying = false
        updateState(.paused)
        onPause?()
    }
    
    @objc public func stop() {
        player?.pause()
        player?.seek(to: .zero)
        isPlaying = false
        updateState(.idle)
    }
    
    @objc public func togglePlayPause() {
        if isPlaying {
            pause()
        } else {
            play()
        }
    }
    
    @objc public func seek(to time: Double) {
        updateState(.seeking)
        let cmTime = CMTime(seconds: time, preferredTimescale: 1000)
        
        player?.seek(to: cmTime, completionHandler: { [weak self] _ in
            self?.updateState(self?.isPlaying == true ? .playing : .paused)
            self?.onSeek?(time)
        })
    }
    
    @objc public func seekForward(seconds: Double = 10) {
        let newTime = currentTime + seconds
        seek(to: min(newTime, duration))
    }
    
    @objc public func seekBackward(seconds: Double = 10) {
        let newTime = currentTime - seconds
        seek(to: max(newTime, 0))
    }
    
    // MARK: - Volume Control
    
    @objc public func setVolume(_ volume: Float) {
        let clampedVolume = max(0, min(1, volume))
        player?.volume = clampedVolume
        onVolumeChange?(clampedVolume)
    }
    
    @objc public func mute() {
        player?.isMuted = true
    }
    
    @objc public func unmute() {
        player?.isMuted = false
    }
    
    @objc public func toggleMute() {
        player?.isMuted = !(player?.isMuted ?? false)
    }
    
    // MARK: - Playback Rate
    
    @objc public func setPlaybackRate(_ rate: Float) {
        player?.rate = rate
    }
    
    @objc public func getPlaybackRate() -> Float {
        return player?.rate ?? 1.0
    }
    
    // MARK: - State Management
    
    private func updateState(_ newState: PlayerState) {
        state = newState
        onStateChange?(newState)
        
        if configuration?.debug == true {
            print("[UnifiedVideoPlayer] State changed to: \(newState)")
        }
    }
    
    // MARK: - Observers
    
    private func setupObservers() {
        // Time observer
        let interval = CMTime(seconds: 0.1, preferredTimescale: 1000)
        timeObserver = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            self?.handleTimeUpdate(time)
        }
        
        // Rate observer (play/pause)
        rateObserver = player?.observe(\.rate, options: [.new]) { [weak self] player, _ in
            self?.handleRateChange(player.rate)
        }
        
        // Status observer
        statusObserver = player?.observe(\.status, options: [.new]) { [weak self] player, _ in
            self?.handleStatusChange(player.status)
        }
        
        // Notification observers
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(playerDidFinishPlaying),
            name: .AVPlayerItemDidPlayToEndTime,
            object: nil
        )
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handlePlaybackStalled),
            name: .AVPlayerItemPlaybackStalled,
            object: nil
        )
    }
    
    private func observePlayerItem(_ playerItem: AVPlayerItem) {
        currentItemObserver = playerItem.observe(\.status, options: [.new]) { [weak self] item, _ in
            self?.handleItemStatusChange(item.status)
        }
        
        // Observe buffering
        playerItem.addObserver(self, forKeyPath: "playbackBufferEmpty", options: .new, context: nil)
        playerItem.addObserver(self, forKeyPath: "playbackLikelyToKeepUp", options: .new, context: nil)
        playerItem.addObserver(self, forKeyPath: "playbackBufferFull", options: .new, context: nil)
    }
    
    override public func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "playbackBufferEmpty" {
            updateState(.buffering)
            onBuffering?(true)
        } else if keyPath == "playbackLikelyToKeepUp" || keyPath == "playbackBufferFull" {
            if isPlaying {
                updateState(.playing)
            } else {
                updateState(.paused)
            }
            onBuffering?(false)
        }
    }
    
    private func handleTimeUpdate(_ time: CMTime) {
        currentTime = time.seconds
        onTimeUpdate?(currentTime)
        
        // Update buffered time
        if let timeRanges = player?.currentItem?.loadedTimeRanges,
           let range = timeRanges.first?.timeRangeValue {
            let bufferedEnd = range.start + range.duration
            bufferedTime = bufferedEnd.seconds
            onProgress?(bufferedTime)
        }
    }
    
    private func handleRateChange(_ rate: Float) {
        isPlaying = rate > 0
    }
    
    private func handleStatusChange(_ status: AVPlayer.Status) {
        switch status {
        case .readyToPlay:
            updateDuration()
            updateState(.ready)
            onReady?()
            emitLoadedMetadata()
        case .failed:
            if let error = player?.error {
                handleError(error)
            }
        default:
            break
        }
    }
    
    private func handleItemStatusChange(_ status: AVPlayerItem.Status) {
        switch status {
        case .readyToPlay:
            updateDuration()
        case .failed:
            if let error = player?.currentItem?.error {
                handleError(error)
            }
        default:
            break
        }
    }
    
    @objc private func playerDidFinishPlaying() {
        updateState(.ended)
        onEnded?()
        
        if configuration?.loop == true {
            seek(to: 0)
            play()
        }
    }
    
    @objc private func handlePlaybackStalled() {
        updateState(.buffering)
        onBuffering?(true)
    }
    
    private func updateDuration() {
        if let duration = player?.currentItem?.duration {
            self.duration = duration.seconds
        }
    }
    
    private func emitLoadedMetadata() {
        guard let item = player?.currentItem else { return }
        
        var metadata: [String: Any] = [:]
        metadata["duration"] = duration
        
        if let videoTrack = item.asset.tracks(withMediaType: .video).first {
            metadata["width"] = videoTrack.naturalSize.width
            metadata["height"] = videoTrack.naturalSize.height
            metadata["fps"] = videoTrack.nominalFrameRate
        }
        
        if let audioTrack = item.asset.tracks(withMediaType: .audio).first {
            metadata["audioChannels"] = audioTrack.formatDescriptions
        }
        
        onLoadedMetadata?(metadata)
    }
    
    // MARK: - UI Controls
    
    private func addDefaultControls() {
        guard let container = containerView else { return }
        
        // Create a simple control overlay
        let controlsView = UIView(frame: container.bounds)
        controlsView.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        controlsView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        controlsView.tag = 999 // Tag for identification
        
        // Play/Pause button
        let playPauseButton = UIButton(type: .system)
        playPauseButton.frame = CGRect(x: container.bounds.width/2 - 30, y: container.bounds.height/2 - 30, width: 60, height: 60)
        playPauseButton.setTitle("▶", for: .normal)
        playPauseButton.titleLabel?.font = UIFont.systemFont(ofSize: 30)
        playPauseButton.tintColor = .white
        playPauseButton.addTarget(self, action: #selector(handlePlayPauseButton), for: .touchUpInside)
        
        controlsView.addSubview(playPauseButton)
        container.addSubview(controlsView)
        
        // Auto-hide controls
        setupControlsAutoHide(controlsView)
    }
    
    private func setupControlsAutoHide(_ controlsView: UIView) {
        // Hide controls after 3 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak controlsView] in
            UIView.animate(withDuration: 0.3) {
                controlsView?.alpha = 0
            }
        }
        
        // Show controls on tap
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleControlsTap))
        containerView?.addGestureRecognizer(tapGesture)
    }
    
    @objc private func handlePlayPauseButton() {
        togglePlayPause()
    }
    
    @objc private func handleControlsTap() {
        guard let controlsView = containerView?.viewWithTag(999) else { return }
        
        UIView.animate(withDuration: 0.3) {
            controlsView.alpha = controlsView.alpha == 0 ? 1 : 0
        }
        
        if controlsView.alpha == 1 {
            // Auto-hide after 3 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak controlsView] in
                UIView.animate(withDuration: 0.3) {
                    controlsView?.alpha = 0
                }
            }
        }
    }
    
    // MARK: - Error Handling
    
    private func handleError(_ error: Error) {
        updateState(.error)
        onError?(error)
        
        if configuration?.debug == true {
            print("[UnifiedVideoPlayer] Error: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Debug
    
    private func enableDebugLogging() {
        print("[UnifiedVideoPlayer] Debug mode enabled")
        print("[UnifiedVideoPlayer] Configuration: \(String(describing: configuration))")
    }
    
    // MARK: - Cleanup
    
    @objc public func destroy() {
        player?.pause()
        
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
        }
        
        statusObserver?.invalidate()
        rateObserver?.invalidate()
        currentItemObserver?.invalidate()
        
        NotificationCenter.default.removeObserver(self)
        
        playerLayer?.removeFromSuperlayer()
        playerViewController?.dismiss(animated: false)
        
        player = nil
        playerLayer = nil
        playerViewController = nil
        containerView = nil
        
        updateState(.idle)
    }
    
    deinit {
        destroy()
    }
}

// MARK: - AVAssetResourceLoaderDelegate (for FairPlay DRM)
extension UnifiedVideoPlayer: AVAssetResourceLoaderDelegate {
    
    public func resourceLoader(_ resourceLoader: AVAssetResourceLoader, shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest) -> Bool {
        // FairPlay DRM implementation
        guard let url = loadingRequest.request.url,
              url.scheme == "skd",
              let drm = currentSource?.drm,
              drm.type == "fairplay" else {
            return false
        }
        
        // Handle FairPlay license request
        handleFairPlayRequest(loadingRequest, drm: drm)
        return true
    }
    
    private func handleFairPlayRequest(_ loadingRequest: AVAssetResourceLoadingRequest, drm: DRMConfiguration) {
        // Implementation for FairPlay license acquisition
        // This would include:
        // 1. Getting the content ID from the URL
        // 2. Getting the SPC (Server Playback Context) from the request
        // 3. Sending the SPC to the license server
        // 4. Processing the CKC (Content Key Context) response
        // 5. Providing the CKC to the loading request
        
        // Simplified example:
        guard let certificateUrl = drm.certificateUrl,
              let certificateURL = URL(string: certificateUrl) else {
            loadingRequest.finishLoading(with: NSError(domain: "UnifiedVideoPlayer", code: -2, userInfo: nil))
            return
        }
        
        // This is a simplified implementation
        // Real implementation would involve proper FairPlay flow
    }
}
