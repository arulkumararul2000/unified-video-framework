#!/bin/bash

# Build Universal Framework for iOS
# Supports arm64 (device) and x86_64 (simulator)

set -e

FRAMEWORK_NAME="UnifiedVideoPlayer"
BUILD_DIR="build"
OUTPUT_DIR="Output"

echo "🔨 Building UnifiedVideoPlayer Framework..."

# Clean previous builds
rm -rf $BUILD_DIR
rm -rf $OUTPUT_DIR

# Build for iOS Device (arm64)
echo "📱 Building for iOS Device (arm64)..."
xcodebuild archive \
  -scheme $FRAMEWORK_NAME \
  -archivePath "$BUILD_DIR/ios_device.xcarchive" \
  -sdk iphoneos \
  -configuration Release \
  SKIP_INSTALL=NO \
  BUILD_LIBRARY_FOR_DISTRIBUTION=YES \
  ARCHS="arm64" \
  ONLY_ACTIVE_ARCH=NO

# Build for iOS Simulator (x86_64 and arm64 for Apple Silicon)
echo "💻 Building for iOS Simulator (x86_64 & arm64)..."
xcodebuild archive \
  -scheme $FRAMEWORK_NAME \
  -archivePath "$BUILD_DIR/ios_simulator.xcarchive" \
  -sdk iphonesimulator \
  -configuration Release \
  SKIP_INSTALL=NO \
  BUILD_LIBRARY_FOR_DISTRIBUTION=YES \
  ARCHS="x86_64 arm64" \
  ONLY_ACTIVE_ARCH=NO \
  EXCLUDED_ARCHS=""

# Create XCFramework
echo "📦 Creating XCFramework..."
xcodebuild -create-xcframework \
  -framework "$BUILD_DIR/ios_device.xcarchive/Products/Library/Frameworks/$FRAMEWORK_NAME.framework" \
  -framework "$BUILD_DIR/ios_simulator.xcarchive/Products/Library/Frameworks/$FRAMEWORK_NAME.framework" \
  -output "$OUTPUT_DIR/$FRAMEWORK_NAME.xcframework"

echo "✅ Build complete! Framework available at: $OUTPUT_DIR/$FRAMEWORK_NAME.xcframework"
echo ""
echo "To use in your project:"
echo "1. Drag $FRAMEWORK_NAME.xcframework into your Xcode project"
echo "2. Make sure it's added to your target's 'Frameworks, Libraries, and Embedded Content'"
echo "3. Set 'Embed & Sign' for the framework"
