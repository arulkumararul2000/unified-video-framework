# iOS Build Instructions - Fixing Architecture Issues

## Problem
The error "UnifiedVideoPlayer.swiftmodule is not built for arm64" occurs when the framework isn't compiled for the correct architecture.

## Solution

### Option 1: Using Swift Package Manager (Recommended)

1. In Xcode, go to **File > Add Package Dependencies**
2. Click "Add Local..." and navigate to `/packages/ios/`
3. Select the package and add it to your target
4. Swift Package Manager will automatically build for the correct architecture

### Option 2: Build Universal Framework

1. Open Terminal and navigate to `/packages/ios/`
2. Run the build script:
   ```bash
   chmod +x build_framework.sh
   ./build_framework.sh
   ```
3. This will create a universal XCFramework in `Output/UnifiedVideoPlayer.xcframework`
4. Drag the `.xcframework` into your Xcode project

### Option 3: Direct Xcode Project Build

1. Open `/packages/ios/UnifiedVideoPlayer.xcodeproj` in Xcode
2. Select your target device/simulator from the scheme selector
3. Go to **Product > Build** (⌘B)
4. The framework will be built for the selected architecture

### Option 4: Manual Architecture Configuration

If you're still experiencing issues:

1. In your app's Xcode project, select your target
2. Go to **Build Settings**
3. Search for "Architectures"
4. Ensure these settings:
   - **Architectures**: Standard Architectures (arm64, arm64e)
   - **Valid Architectures**: arm64 arm64e x86_64
   - **Build Active Architecture Only**: 
     - Debug: Yes (for faster builds)
     - Release: No (for distribution)
   - **Excluded Architectures**: Leave empty or remove any entries

### Architecture Reference

- **arm64**: Physical iOS devices (iPhone 6s and later)
- **arm64e**: Newer iOS devices (iPhone XS and later)
- **x86_64**: Intel-based Mac simulators
- **arm64** (simulator): Apple Silicon Mac simulators

### Troubleshooting

1. **Clean Build Folder**: Product > Clean Build Folder (⇧⌘K)
2. **Delete Derived Data**: 
   - Xcode > Settings > Locations
   - Click arrow next to Derived Data path
   - Delete the folder for your project
3. **Reset Package Caches**: File > Packages > Reset Package Caches
4. **Check Deployment Target**: Ensure iOS deployment target is 13.0 or higher

### Using in Your Project

```swift
import UnifiedVideoPlayer

struct ContentView: View {
    var body: some View {
        UnifiedVideoPlayerView(url: URL(string: "https://example.com/video.mp4")!)
    }
}
```

## Build from Command Line

For CI/CD or command-line builds:

```bash
# Build for simulator
xcodebuild -scheme UnifiedVideoPlayer \
  -sdk iphonesimulator \
  -configuration Release \
  -arch x86_64 \
  -arch arm64 \
  build

# Build for device
xcodebuild -scheme UnifiedVideoPlayer \
  -sdk iphoneos \
  -configuration Release \
  -arch arm64 \
  build

# Create XCFramework (universal)
xcodebuild -create-xcframework \
  -framework path/to/device.framework \
  -framework path/to/simulator.framework \
  -output UnifiedVideoPlayer.xcframework
```

## Notes

- Always use `.xcframework` for distributing binary frameworks as it supports multiple architectures
- When archiving for App Store, ensure "Build Active Architecture Only" is set to NO
- For development, you can use "Build Active Architecture Only = YES" for faster builds
